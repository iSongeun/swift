//
//  ParsingTestViewController.swift
//  Parsing
//
//  Created by 이송은 on 2022/10/25.
//

import UIKit
import SwiftSoup

class ParsingTestViewController: UIViewController {

    @IBOutlet weak var carImage: UIImageView!
    
    @IBOutlet weak var carLabel: UILabel!
    
    @IBOutlet weak var fuelEfficiencyLabel: UILabel!
    
    @IBOutlet weak var fuelLabel: UILabel!
    
    @IBOutlet weak var powerLabel: UILabel!
    
    
    
    @IBOutlet weak var saleLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //crawl()
        //crawl2()
        crawl3()
    }

    func crawl(){
        let url = URL(string: "https://www.aladin.co.kr/shop/common/wbest.aspx?BranchType=1&start=we")
        
        guard let myURL = url else {   return    }
        
        do {
            let html = try String(contentsOf: myURL, encoding: .utf8)
            let doc: Document = try SwiftSoup.parse(html)
            let headerTitle = try doc.title()
            print(headerTitle)
            
            let firstLinkTitles:Elements = try doc.select(".bo3").select("b") //.은 클래스
            for i in firstLinkTitles {
                print("title: ", try i.text())
            }
            
            
        } catch Exception.Error(let type, let message) {
            print("Message: \(message)")
        } catch {
            print("error")
        }
        
    }
    
    func crawl2(){
        let url = URL(string: "https://www.aladin.co.kr/shop/common/wbest.aspx?BranchType=7")
        
        guard let myURL = url else {   return    }
        
        do {
            let html = try String(contentsOf: myURL, encoding: .utf8)
            let doc: Document = try SwiftSoup.parse(html)
            let headerTitle = try doc.title()
            print(headerTitle)
            
            let firstLinkTitles:Elements = try doc.select(".bo3").select("b") //.은 클래스
            for i in firstLinkTitles {
                print("title: ", try i.text())

            }
            
            
        } catch Exception.Error(let type, let message) {
            print("Message: \(message)")
        } catch {
            print("error")
        }
    }
    
    func crawl3(){
        let url = URL(string: "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4")
        
        guard let myURL = url else {   return    }
        
        do {
            let html = try String(contentsOf: myURL, encoding: .utf8)
            let doc: Document = try SwiftSoup.parse(html)
            let headerTitle = try doc.title()
            let text = try doc.select("wrap-new api_animation")
            print(headerTitle)
            
            let textext:Elements = try doc.select("place-app-root").select("place-main-section-root").select("api_subject_bx").select("place_section no_margin vKA6F Aqsow").select("place_section_content").select("y4sYp Xprhw").select("SF_Mq GFtzE Xprhw").select("x8JmK")
            let firstLinkTitles:Elements = try doc.select(".bo3").select("b") //.은 클래스
            for i in firstLinkTitles {
                //print("title: ", try i.text())
            }
            print("title: ", textext )

            
        } catch Exception.Error(let type, let message) {
            print("Message: \(message)")
        } catch {
            print("error")
        }
    }
}
