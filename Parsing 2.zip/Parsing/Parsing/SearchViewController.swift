//
//  SearchViewController.swift
//  Parsing
//
//  Created by 이송은 on 2022/10/26.
//

import UIKit
class placeCell : UITableViewCell{
    
}

class SearchViewController: UIViewController {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 5
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        <#code#>
//    }
//    
//    func updateSearchResults(for searchController: UISearchController) {
//        guard let text = searchController.searchBar.text else{return}
//        print(text)
//        
//    }
//
//    
//    var tableView : UITableView!
//
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        makeTableView()
//        makeSearchBar()
//        // Do any additional setup after loading the view.
//    }
//    
//    func makeTableView(){
//        tableView = UITableView()
//        tableView.dataSource = self
//        self.view.addSubview(tableView)
//        self.tableView.register(UITableView.self, forCellReuseIdentifier: "mountainCell")
//        
//        self.tableView.translatesAutoresizingMaskIntoConstraints = false
//        self.view.addConstraint(NSLayoutConstraint(item: self.tableView!, attribute: .top, relatedBy: .equal, toItem: self.view, attribute: .top, multiplier: 1.0, constant: 0))
//        self.view.addConstraint(NSLayoutConstraint(item: self.tableView!, attribute: .bottom, relatedBy: .equal, toItem: self.view, attribute: .bottom, multiplier: 1.0, constant: 0))
//        self.view.addConstraint(NSLayoutConstraint(item: self.tableView!, attribute: .leading, relatedBy: .equal, toItem: self.view, attribute: .leading, multiplier: 1.0, constant: 0))
//        self.view.addConstraint(NSLayoutConstraint(item: self.tableView!, attribute: .trailing, relatedBy: .equal, toItem: self.view, attribute: .trailing, multiplier: 1.0, constant: 0))
//    }
//    
//    func makeSearchBar(){
//        let searchController = UISearchController(searchResultsController: nil)
//        searchController.searchBar.placeholder = "검색"
//        searchController.obscuresBackgroundDuringPresentation = false
//        searchController.searchResultsUpdater = self
//        
//        self.navigationItem.hidesSearchBarWhenScrolling = false
//        self.navigationItem.searchController = searchController
//        self.navigationItem.title = "search"
//        self.navigationController?.navigationBar.prefersLargeTitles = true
//    }

}
