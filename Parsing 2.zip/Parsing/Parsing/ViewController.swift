//
//  ViewController.swift
//  Parsing
//
//  Created by 이송은 on 2022/10/24.
//

import UIKit
import SwiftSoup

class ViewController: UIViewController {
    
    var timer = Timer()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        timer = Timer.scheduledTimer(withTimeInterval: 5, repeats: false, block: { [weak self] _ in
            // time to Work.
            self?.dismiss(animated: true)
            let alert = UIAlertController(title: "실패", message: "", preferredStyle: .alert)
                        let close = UIAlertAction(title: "닫기", style: .default) { (action) in
                            self?.dismiss(animated: true)
          }
                alert.addAction(close)
            self?.present(alert, animated: true, completion: nil)
        })
    }
}

