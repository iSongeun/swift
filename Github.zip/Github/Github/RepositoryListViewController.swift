//
//  RepositoryListViewController.swift
//  Github
//
//  Created by 이송은 on 2022/11/25.
//

import Foundation
import UIKit

class RepositoryListViewController : UITableViewController{
    
}
